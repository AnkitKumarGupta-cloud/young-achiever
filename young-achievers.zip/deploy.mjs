// One-command deploy to Vercel. Run from the project folder, on your own computer:
//   npx vercel login        (once)
//   node deploy.mjs
// It reads your keys from .env.local and sends them to Vercel itself; nothing is printed.
import { readFileSync, existsSync } from 'node:fs';
import { spawnSync } from 'node:child_process';

if (!existsSync('.env.local')) {
  console.error('Missing .env.local. Put it next to package.json first.');
  process.exit(1);
}

const env = {};
for (const line of readFileSync('.env.local', 'utf8').split(/\r?\n/)) {
  const t = line.trim();
  if (!t || t.startsWith('#') || !t.includes('=')) continue;
  const i = t.indexOf('=');
  env[t.slice(0, i).trim()] = t.slice(i + 1).trim();
}

const NAMES = [
  'NEXT_PUBLIC_SUPABASE_URL',
  'NEXT_PUBLIC_SUPABASE_ANON_KEY',
  'SUPABASE_SERVICE_ROLE_KEY',
  'AUTH_EMAIL_DOMAIN',
];
for (const n of NAMES) {
  if (!env[n] || env[n].startsWith('your-') || env[n].includes('YOUR-')) {
    console.error(`${n} is missing or still a placeholder in .env.local`);
    process.exit(1);
  }
}

function vercel(args, input) {
  return spawnSync('npx', ['vercel', ...args], {
    input,
    stdio: [input === undefined ? 'inherit' : 'pipe', 'inherit', 'inherit'],
    shell: true,
  });
}

console.log('1/3 Linking this folder to a Vercel project…');
let r = vercel(['link', '--yes']);
if (r.status !== 0) {
  console.error('Could not link. Run "npx vercel login" first, then try again.');
  process.exit(1);
}

console.log('2/3 Setting environment variables…');
for (const n of NAMES) {
  spawnSync('npx', ['vercel', 'env', 'rm', n, 'production', '--yes'], { stdio: 'ignore', shell: true });
  r = vercel(['env', 'add', n, 'production'], env[n] + '\n');
  if (r.status !== 0) {
    console.error(`Failed to set ${n}.`);
    process.exit(1);
  }
  console.log(`   set ${n}`);
}

console.log('3/3 Deploying to production…');
r = vercel(['--prod', '--yes']);
process.exit(r.status ?? 1);
